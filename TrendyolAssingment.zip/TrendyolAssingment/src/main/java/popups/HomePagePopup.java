package popups;

import models.component.WebComponent;
import models.component.popup.Popup;

public class HomePagePopup extends Popup {
    public HomePagePopup(WebComponent opener){
        this.opener = opener;
        this.browser = opener.browser();
        this.className = "homepage-popup";
    }
}
