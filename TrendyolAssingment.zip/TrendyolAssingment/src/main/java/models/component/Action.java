package models.component;

import actions.CloseAction;

@FunctionalInterface
public interface Action {
    static Action close(){return new CloseAction();}

    void execIn(WebComponent component);
}
