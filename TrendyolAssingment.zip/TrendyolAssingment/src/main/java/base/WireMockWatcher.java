package base;

import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;
import wiremock.WireMockManager;

public class WireMockWatcher implements TestRule {

    private static Statement statement(Statement base) {
        return new Statement() {
            @Override
            public void evaluate() throws Throwable {
                try{
                    WireMockManager.start();
                    base.evaluate();

                }finally {
                    WireMockManager.stop();
                }
            }
        };
    }

    @Override
    public Statement apply(Statement base, Description description) {
        return statement(base);
    }
}
